<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intern Management System </title>
    <link rel="stylesheet" href="styles.css">
    <!--Font Awesome CDN Link for Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>

    <div class="wrapper">
        <header>File Uploader For Intern Management System</header>
        <form method="post" action="<?=htmlspecialchars('result.php'); ?>" enctype="multipart/form-data">
            <input type="file" name="dosya" class="file-input" hidden>
            <i class="fas fa-cloud-upload-alt"></i>
            <div class="form-group">
              <input type="file" class="form-control-file" name="myFile">
            </div>
            <button type="submit" class="btn btn-danger" > upload</button>
</form>



<section class="progress-area">
    <li class="row">
        <i class="fas fa-file-alt"></i>
        <div class="content">
            <div class="details">
                <span class="name">image_01.png Uploading</span>
            <span class="percent">50%</span>
            </div>
            <div class="progress-bar">
                <div class="progress"></div>
            </div>
        </div>

    </li>

</section>
<section class="upload-area">
    <li class="row">
            <div class="content">

             <i class="fas fa-file-alt"></i>
             <div class="details">
                <span class="name">image_01.png Uploaded</span>
            <span class="size">70KB</span>
            </div>
           </div>
<i class="fas fa-check"></i>
  </li>
  <li class="row">
    <div class="content">

     <i class="fas fa-file-alt"></i>
     <div class="details">
        <span class="name">image_01.png Uploaded</span>
    <span class="size">70KB</span>
    </div>
   </div>
<i class="fas fa-check"></i>
</li>
<li class="row">
    <div class="content">

     <i class="fas fa-file-alt"></i>
     <div class="details">
        <span class="name">image_01.png Uploaded</span>
    <span class="size">70KB</span>
    </div>
   </div>
<i class="fas fa-check"></i>
</li>
<li class="row">
    <div class="content">

     <i class="fas fa-file-alt"></i>
     <div class="details">
        <span class="name">image_01.png Uploaded</span>
    <span class="size">70KB</span>
    </div>
   </div>
<i class="fas fa-check"></i>
</li>
</section>
    </div>
<script src="script.js"></script>
</body>
</html>
