<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Uploads</title>
</head>
<body>


<div class="container-fluid">
   <div class="row">
    <div class="card mt-3 bg-light">
     <div class="card-body">
        <?php
         $takeFile = $_FILES["myFile"];
         $fileName=$takeFile["name"];
         $fileType=$takeFile["type"];
         $fileSize=$takeFile["size"];
         $fileTempName=$takeFile["tmp_name"];
         $myPath ="uploads/".$fileName;

         if(move_uploaded_file($fileTempName,$myPath)) {
            echo "Dosya yüklendi <br>";
            echo "Dosya adı  : $fileName <br>";
            echo "Dosya türü : $fileType <br>";
            echo "Dosya boyutu : $fileSize <br>";

         } else {
          echo 'Dosya yüklenemedi !  <br>';
         }

        ?>



     </div>
    </div>
  <div>
</div>


</body>
</html>
